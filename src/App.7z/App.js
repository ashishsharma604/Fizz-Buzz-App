import React from 'react';
import logo from './logo.svg';
import './App.css';
import InputComponent from './components/TakeInputComponent'
function App() {
  return (
    <div className="App">
      <h1>Fizz Buzz Application</h1>
      <InputComponent />
    </div>
  );
}

export default App;
